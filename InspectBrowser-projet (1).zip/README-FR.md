# Inspect Browser — prototype Android

Ce projet crée un navigateur Android simple avec une barre d'adresse et un bouton **Inspecter**. Le bouton ouvre Eruda, une boîte à outils de développement dans la page (console, éléments/DOM selon la version, réseau et informations).

## Important
- Ce fichier ZIP est le **projet source**, pas encore un APK installable.
- Je ne peux pas compiler/signature Android directement dans cet environnement. Le workflow GitHub inclus fabrique un APK de test (`app-debug.apk`).
- Eruda est chargé depuis jsDelivr : une connexion Internet est nécessaire. Certains sites bloquent l'injection de scripts avec leurs règles de sécurité (CSP), donc l'inspection ne fonctionnera pas sur absolument tous les sites.
- C'est un prototype de navigateur, pas encore un navigateur complet : pas de gestion avancée des onglets, téléchargements, favoris ou navigation privée.
- N'utilise pas l'inspecteur pour contourner les protections d'un site ou modifier des données auxquelles tu n'as pas droit.

## Générer l'APK depuis un téléphone
1. Crée un compte GitHub si tu n'en as pas.
2. Dans GitHub, crée un nouveau dépôt (repository).
3. Envoie-y tous les fichiers de ce ZIP en conservant les dossiers.
4. Ouvre l'onglet **Actions**, sélectionne **Build Android APK**, puis **Run workflow**.
5. Quand le travail est terminé, ouvre-le et télécharge l'artefact `InspectBrowser-debug-apk`.
6. Décompresse l'artefact et installe `app-debug.apk` sur ton Android. Android peut demander d'autoriser l'installation depuis cette source.

## Utilisation
1. Ouvre Inspect Browser.
2. Entre l'adresse d'un site puis touche **Aller**.
3. Touche **Inspecter** pour ouvrir les outils Eruda. Touche encore pour les masquer.

Pour une version publique, il faudra signer une version release et tester l'application sur plusieurs téléphones.
