package com.example.inspectbrowser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.Gravity;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText address;
    private boolean inspectorVisible = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(8, 8, 8, 8);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(245,245,245));

        address = new EditText(this);
        address.setSingleLine(true);
        address.setText("https://example.com");
        address.setHint("Adresse du site");
        address.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.addView(address, new LinearLayout.LayoutParams(0, 48, 1));

        Button go = new Button(this);
        go.setText("Aller");
        bar.addView(go);

        Button inspect = new Button(this);
        inspect.setText("Inspecter");
        bar.addView(inspect);

        root.addView(bar);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                address.setText(url);
                injectEruda();
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        go.setOnClickListener(v -> loadAddress());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) { loadAddress(); return true; }
            return false;
        });
        inspect.setOnClickListener(v -> {
            inspectorVisible = !inspectorVisible;
            if (inspectorVisible) {
                injectEruda();
                webView.evaluateJavascript(
                    "if(window.eruda){eruda.show();}else{alert('Chargement de l’inspecteur… Réessaie dans quelques secondes.');}", null);
            } else {
                webView.evaluateJavascript("if(window.eruda){eruda.hide();}", null);
            }
        });

        webView.loadUrl("https://example.com");
    }

    private void loadAddress() {
        String url = address.getText().toString().trim();
        if (url.isEmpty()) return;
        if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        inspectorVisible = false;
        webView.loadUrl(url);
    }

    private void injectEruda() {
        String js = "(function(){if(window.__inspectBrowserErudaLoading||window.eruda)return;"
          + "window.__inspectBrowserErudaLoading=true;"
          + "var s=document.createElement('script');"
          + "s.src='https://cdn.jsdelivr.net/npm/eruda';"
          + "s.onload=function(){window.eruda.init(); if(" + inspectorVisible + ")window.eruda.show();};"
          + "s.onerror=function(){window.__inspectBrowserErudaLoading=false;};"
          + "document.documentElement.appendChild(s);})();";
        webView.evaluateJavascript(js, null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
